function params = chainer_init_params(x,opts)
% This function initializes chain parameters

%% Concentrations

params.a = opts.a;
params.g = opts.g;

%% priors for the emission parameters

% params.Q = [ lambda, rho, beta, omega ];
params.Q = opts.Q;


%% other sampler's parameters

params.Brep = 25;
params.Frep = 25;

