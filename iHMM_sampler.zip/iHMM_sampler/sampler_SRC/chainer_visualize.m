function G = chainer_visualize( G, r, chain, x )
% This function visualizes the r-th sample of the chain

N = length(x);

if isempty(G)

    % show labels
    fl = false;

    figure
    
    % Set ranges
    y_lim = [min(x) max(x)];
    s_lim = [0 1.2*std(x)];
    
    
    % upper left
    subplot(4,5,[1 2 3 4])
    G.g1 = plot(1:chain.r_max,chain.K,'o-');
    if fl
        text(0.5,0.5,{'G.g1'},'units','normalized','FontWeight','Bold','FontSize',20)
    end
        xlim([0 chain.r_max+1])
    ylim([0 max(10,min(30,max(get(gca,'Ylim'))))])
    set(gca,'XAxisLocation','top')
    grid on
    ylabel('K')
    xlabel('Iteration (r)')
    box off
    
    
    % lower left
    subplot(4,5,[6 7 8 9  11 12 13 14  16 17 18 19])
    G.g2 = plot(1:N,x,'c-',...
                1:N,chain.F{r}(chain.s(r,:)),'-o' );
    if fl
        text(0.5,0.5,{'G.g2'},'units','normalized','FontWeight','Bold','FontSize',20)
    end
    grid on
    ylabel('Signals')
    xlabel('Time (n)')
    ylim( y_lim )
    xlim([0 N+1])
    legend('x','f','location','NW')
    box off
   
    
    % lower right
    subplot(4,5,[10 15 20])
    y_temp = linspace(y_lim(1),y_lim(end),100);
    x_temp = 0*y_temp;
    for k = 1:chain.K(r)
        x_temp = x_temp + chain.B{r}(k)*sqrt(0.5*chain.F{r}(k,2)/pi)*exp( -0.5*chain.F{r}(k,2)*(y_temp-chain.F{r}(k,1)).^2 );
    end
    G.h1 = histogram(x,linspace(y_lim(1),y_lim(2),50),'facecolor','c','orientation','horizontal','normalization','pdf');
    G.g3 = line( x_temp, y_temp );
    if fl
        text(0.5,0.5,{'G.h1','G.g3'},'units','normalized','FontWeight','Bold','FontSize',20)
    end
    ylim([y_temp(1) y_temp(end)])
    xlim(get(gca,'Xlim').*[1 1.2])
    set(gca,'XTickLabel',[],'YTickLabel',[])
    box off
    
    
    % upper right
    subplot(4,5,5)
    m_temp = linspace(y_lim(1),y_lim(2));
    s_temp = linspace(s_lim(1),s_lim(2));
    m_pdf = normpdf(m_temp,chain.params.Q(1),sqrt(1/chain.params.Q(2)));
    s_pdf = max(0,2./s_temp.^3).*gampdf( 1./s_temp.^2, chain.params.Q(3)/2, 2/(chain.params.Q(4)*chain.params.Q(3)) );
    line(s_temp,y_lim(2)-0.25*(y_lim(2)-y_lim(1))*s_pdf/max(s_pdf),'linestyle','-','color','c')
    line(s_lim(2)-0.25*(s_lim(2)-s_lim(1))*m_pdf/max(m_pdf),m_temp,'linestyle','-','color','c')
    G.g4 = line( 1./sqrt(chain.F{r}(:,2)), chain.F{r}(:,1),'marker','o','linestyle','none');
    if fl
        text(0.5,0.5,{'G.g4'},'units','normalized','FontWeight','Bold','FontSize',20)
    end
    ylim(y_lim)
    xlim(s_lim)
    line(get(gca,'xlim'), mean(x)*[1 1],'color','c','linestyle','--')
    line(  std(x)*[1 1],get(gca,'ylim'),'color','c','linestyle','--')
    set(gca,'XAxisLocation','top','YAxisLocation','right') 
    ylabel('\mu')
    xlabel('\sigma')


    
    
    
else
    
    
    set(G.g1   ,'YData',chain.K);

    set(G.g2(2),'YData',chain.F{r}(chain.s(r,:),1))
   
    y_temp = get(G.g3,'Ydata');
    x_temp = 0*y_temp;
    for k = 1:chain.K(r)
        x_temp = x_temp + chain.B{r}(k)*sqrt(0.5*chain.F{r}(k,2)/pi)*exp( -0.5*chain.F{r}(k,2)*(y_temp-chain.F{r}(k,1)).^2 );
    end
    set(G.g3,'XData',x_temp)
    
    set(G.g4,'XData', 1./sqrt(chain.F{r}(:,2)), 'YData', chain.F{r}(:,1));
    
    
    
end

drawnow
