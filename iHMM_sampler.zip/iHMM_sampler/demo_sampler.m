clear all

%% Link with sampler's source
addpath('sampler_SRC')


%% Import some data
x = load('demo_data.txt');


%% Set iHMM's parameters

% Concentrations
opts.a = 1; % Transitions (alpha)
opts.g = 1; % Base (gamma)

% Emission hyper-parameters
opts.Q(1) = mean(x);        % mean of emission means (lambda)
opts.Q(2) = 1/std(x)^2;     % Precision of emission means (rho)
opts.Q(3) = 1;              % Shape of emission precisions (beta)
opts.Q(4) = 0.10;           % Scale of emission precisions (omega)


%% Set sampler's parameters

opts.dr_sk  = 1;    % Stride, ie keep samples every dr_sk itterations
opts.K_init = 10;   % Initial number of states


%% Set output flags

flag_stat = true;   % Print progress report in command line
flag_anim = true;   % Visualize current sample


%% Create a chain and generate few samples

R = 500; % number of samples to be generated

chain = chainer_main( x, R, [], opts, flag_stat, flag_anim );   % run sampler


%% Expand the chain by generating more samples

R = 2000; % number of samples to be generated

chain = chainer_main( x, R, chain, [], flag_stat, flag_anim );  % run sampler


%% Store samples for external analysis

fr = 0.25;  % fraction of samples to be discarded due to burn-in
dr = 2;     % samples stride, ie export every dr sample

chainer_export(chain,fr,dr,'samples','mat')


%% Perform some preliminary analysis

% discretize state space
m_min = 0;
m_max = 1;
m_num = 25;

% estimate state trajectory
[m_mod,m_red] = chainer_analyze_means(chain,fr,dr,m_min,m_max,m_num,x);

% estimate transition matrix
[m_edges,p_mean,d_dist] = chainer_analyze_transitions(chain,fr,dr,m_min,m_max,m_num,true);



